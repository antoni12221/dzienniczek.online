DZIENNIK ONLINE — WERSJA STARTOWA

1. Wgraj plik index.html na hosting stron internetowych.
2. Otwórz otrzymany adres strony.
3. Konto nauczyciela:
   login: nauczyciel
   hasło: 1234
4. Konto ucznia:
   login: uczen
   hasło: 1234

UWAGA:
Ta wersja jest demonstracyjna. Dane zapisują się w pamięci przeglądarki (localStorage), więc nie są jeszcze wspólną bazą danych dla wielu urządzeń.
Do prawdziwego dziennika online z kontami, wspólnymi danymi i bezpiecznym logowaniem potrzebny jest backend/baza danych.
